Most of the code in this package was copied from the Gio project. 

Changes made is listed below:

1. Enable the input of Tab.
2. Exported APIs to calculate viewport offset and setting scrollbar offset.
2. Added colorful glyphs painting.