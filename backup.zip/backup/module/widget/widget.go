package widget

import "gioui.org/layout"

type (
	C = layout.Context
	D = layout.Dimensions
)
